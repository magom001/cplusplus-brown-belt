#include <iostream>
#include "program_runner.h"


#include <sstream>

using namespace std;

int main() {
    cin.tie(nullptr);
    ios_base::sync_with_stdio(false);

    Start(cin, cout);

    return 0;
}