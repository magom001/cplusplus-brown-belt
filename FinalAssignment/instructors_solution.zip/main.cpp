#include "graph.h"
#include "json.h"
#include "router.h"
#include "sphere.h"
#include "utils.h"

#include <algorithm>
#include <cassert>
#include <fstream>
#include <iostream>
#include <memory>
#include <optional>
#include <sstream>
#include <string>
#include <string_view>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <variant>
#include <vector>

using namespace std;

namespace Descriptions {
  struct Stop {
    string name;
    Sphere::Point position;
    unordered_map<string, int> distances;

    static Stop ParseFrom(const Json::Dict& attrs) {
      Stop stop = {
          .name = attrs.at("name").AsString(),
          .position = {
              .latitude = attrs.at("latitude").AsDouble(),
              .longitude = attrs.at("longitude").AsDouble(),
          }
      };
      if (attrs.count("road_distances") > 0) {
        for (const auto& [neighbour_stop, distance_node] : attrs.at("road_distances").AsMap()) {
          stop.distances[neighbour_stop] = distance_node.AsInt();
        }
      }
      return stop;
    }
  };

  vector<string> ParseStops(const vector<Json::Node>& stop_nodes, bool is_roundtrip) {
    vector<string> stops;
    stops.reserve(stop_nodes.size());
    for (const Json::Node& stop_node : stop_nodes) {
      stops.push_back(stop_node.AsString());
    }
    if (is_roundtrip || stops.size() <= 1) {
      return stops;
    }
    stops.reserve(stops.size() * 2 - 1);  // end stop is not repeated
    for (size_t stop_idx = stops.size() - 1; stop_idx > 0; --stop_idx) {
      stops.push_back(stops[stop_idx - 1]);
    }
    return stops;
  }

  struct Bus {
    string name;
    vector<string> stops;

    static Bus ParseFrom(const Json::Dict& attrs) {
      return Bus{
          .name = attrs.at("name").AsString(),
          .stops = ParseStops(attrs.at("stops").AsArray(), attrs.at("is_roundtrip").AsBool()),
      };
    }
  };

  using InputQuery = variant<Stop, Bus>;

  vector<InputQuery> ReadDescriptions(const vector<Json::Node>& nodes) {
    vector<InputQuery> result;
    result.reserve(nodes.size());

    for (const Json::Node& node : nodes) {
      const auto& node_dict = node.AsMap();
      if (node_dict.at("type").AsString() == "Bus") {
        result.push_back(Bus::ParseFrom(node_dict));
      } else {
        result.push_back(Stop::ParseFrom(node_dict));
      }
    }

    return result;
  }
}

namespace Responses {
  struct Stop {
    set<string> bus_names;
  };

  struct Bus {
    size_t stop_count = 0;
    size_t unique_stop_count = 0;
    int road_route_length = 0;
    double geo_route_length = 0.0;
  };
}

class Database {
private:
  using Bus = Responses::Bus;
  using Stop = Responses::Stop;
  using BusGraph = Graph::DirectedWeightedGraph<double>;
  using Router = Graph::Router<double>;
  using StopsInfo = unordered_map<string, const Descriptions::Stop*>;

public:
  explicit Database(vector<Descriptions::InputQuery> data, const Json::Dict& routing_settings_json) {
    auto stops_end = partition(begin(data), end(data), [](const auto& item) {
      return holds_alternative<Descriptions::Stop>(item);
    });

    StopsInfo stops_info;
    for (const auto& item : Range{begin(data), stops_end}) {
      const auto& stop = get<Descriptions::Stop>(item);
      stops_info[stop.name] = &stop;
      stops_.insert({stop.name, {}});
    }

    Range buses_range{stops_end, end(data)};
    for (const auto& item : buses_range) {
      const auto& bus = get<Descriptions::Bus>(item);

      buses_[bus.name] = Bus{
        bus.stops.size(),
        ComputeUniqueItemsCount(AsRange(bus.stops)),
        ComputeRoadRouteLength(bus.stops, stops_info),
        ComputeGeoRouteDistance(bus.stops, stops_info)
      };

      for (const string& stop_name : bus.stops) {
        stops_.at(stop_name).bus_names.insert(bus.name);
      }
    }

    routing_settings_ = MakeRoutingSettings(routing_settings_json);
    BuildGraph(stops_info, buses_range);
  }

  const Stop* GetStop(const string& name) const {
    return GetValuePointer(stops_, name);
  }

  const Bus* GetBus(const string& name) const {
    return GetValuePointer(buses_, name);
  }

  struct RouteInfo {
    double total_time;

    struct BusItem {
      string bus_name;
      double time;
      size_t span_count;
    };
    struct WaitItem {
      string stop_name;
      double time;
    };

    using Item = variant<BusItem, WaitItem>;
    vector<Item> items;
  };

  optional<RouteInfo> FindRoute(const string& stop_from, const string& stop_to) const {
    const Graph::VertexId vertex_from = stops_vertex_ids_.at(stop_from).out;
    const Graph::VertexId vertex_to = stops_vertex_ids_.at(stop_to).out;
    const auto route = router_->BuildRoute(vertex_from, vertex_to);
    if (!route) {
      return nullopt;
    }

    RouteInfo route_info = {.total_time = route->weight};
    route_info.items.reserve(route->edge_count);
    for (size_t edge_idx = 0; edge_idx < route->edge_count; ++edge_idx) {
      const Graph::EdgeId edge_id = router_->GetRouteEdge(route->id, edge_idx);
      const auto& edge = graph_.GetEdge(edge_id);
      const auto& edge_info = edges_info_[edge_id];
      if (holds_alternative<BusEdgeInfo>(edge_info)) {
        const BusEdgeInfo& bus_edge_info = get<BusEdgeInfo>(edge_info);
        route_info.items.push_back(RouteInfo::BusItem{
            .bus_name = bus_edge_info.bus_name,
            .time = edge.weight,
            .span_count = bus_edge_info.span_count,
        });
      } else {
        const Graph::VertexId vertex_id = edge.from;
        route_info.items.push_back(RouteInfo::WaitItem{
            .stop_name = vertices_info_[vertex_id].stop_name,
            .time = edge.weight,
        });
      }
    }

    // Releasing in destructor of some proxy object would be better,
    // but we do not expect exceptions in normal workflow
    router_->ReleaseRoute(route->id);
    return route_info;
  }

private:
  static int ComputeStopsDistance(const Descriptions::Stop& lhs, const Descriptions::Stop& rhs) {
    if (auto it = lhs.distances.find(rhs.name); it != lhs.distances.end()) {
      return it->second;
    } else {
      return rhs.distances.at(lhs.name);
    }
  }

  static int ComputeRoadRouteLength(
    const vector<string>& stops,
    const StopsInfo& stops_info
  ) {
    int result = 0;
    for (size_t i = 1; i < stops.size(); ++i) {
      result += ComputeStopsDistance(*stops_info.at(stops[i - 1]), *stops_info.at(stops[i]));
    }
    return result;
  }

  static double ComputeGeoRouteDistance(
    const vector<string>& stops,
    const StopsInfo& stops_info
  ) {
    double result = 0;
    for (size_t i = 1; i < stops.size(); ++i) {
      result += Sphere::Distance(
        stops_info.at(stops[i - 1])->position, stops_info.at(stops[i])->position
      );
    }
    return result;
  }

  struct RoutingSettings {
    int bus_wait_time;  // in minutes
    double bus_velocity;  // km/h
  };

  static RoutingSettings MakeRoutingSettings(const Json::Dict& json) {
    return {
        json.at("bus_wait_time").AsInt(),
        json.at("bus_velocity").AsDouble(),
    };
  }

  void FillGraphWithStops(const StopsInfo& stops_info) {
    Graph::VertexId vertex_id = 0;

    for (const auto& [stop_name, _] : stops_info) {
      auto& vertex_ids = stops_vertex_ids_[stop_name];
      vertex_ids.in = vertex_id++;
      vertex_ids.out = vertex_id++;
      vertices_info_[vertex_ids.in] = {stop_name};
      vertices_info_[vertex_ids.out] = {stop_name};

      edges_info_.push_back(WaitEdgeInfo{});
      const Graph::EdgeId edge_id = graph_.AddEdge({
          vertex_ids.out,
          vertex_ids.in,
          static_cast<double>(routing_settings_.bus_wait_time)
      });
      assert(edge_id == edges_info_.size() - 1);
    }

    assert(vertex_id == graph_.GetVertexCount());
  }

  template <typename BusesRange>
  void FillGraphWithBuses(const StopsInfo& stops_info, BusesRange buses_range) {
    for (const auto& bus_item : buses_range) {
      const auto& bus = get<Descriptions::Bus>(bus_item);
      const size_t stop_count = bus.stops.size();
      if (stop_count <= 1) {
        continue;
      }
      auto compute_distance_from = [&stops_info, &bus](size_t lhs_idx) {
        return ComputeStopsDistance(*stops_info.at(bus.stops[lhs_idx]), *stops_info.at(bus.stops[lhs_idx + 1]));
      };
      for (size_t start_stop_idx = 0; start_stop_idx + 1 < stop_count; ++start_stop_idx) {
        const Graph::VertexId start_vertex = stops_vertex_ids_[bus.stops[start_stop_idx]].in;
        int total_distance = 0;
        for (size_t finish_stop_idx = start_stop_idx + 1; finish_stop_idx < stop_count; ++finish_stop_idx) {
          total_distance += compute_distance_from(finish_stop_idx - 1);
          edges_info_.push_back(BusEdgeInfo{
              .bus_name = bus.name,
              .span_count = finish_stop_idx - start_stop_idx,
          });
          const Graph::EdgeId edge_id = graph_.AddEdge({
              start_vertex,
              stops_vertex_ids_[bus.stops[finish_stop_idx]].out,
              total_distance * 1.0 / (routing_settings_.bus_velocity * 1000.0 / 60)  // m / (km/h * 1000 / 60) = min
          });
          assert(edge_id == edges_info_.size() - 1);
        }
      }
    }
  }

  template <typename BusesRange>
  void BuildGraph(const StopsInfo& stops_info, BusesRange buses_range) {
    const size_t vertex_count = stops_info.size() * 2;
    vertices_info_.resize(vertex_count);
    graph_ = BusGraph(vertex_count);

    FillGraphWithStops(stops_info);
    FillGraphWithBuses(stops_info, buses_range);

    router_ = make_unique<Router>(graph_);
  }

  struct StopVertexIds {
    Graph::VertexId in;
    Graph::VertexId out;
  };
  struct VertexInfo {
    string stop_name;
  };

  struct BusEdgeInfo {
    string bus_name;
    size_t span_count;
  };
  struct WaitEdgeInfo {};
  using EdgeInfo = variant<BusEdgeInfo, WaitEdgeInfo>;

  unordered_map<string, Stop> stops_;
  unordered_map<string, Bus> buses_;

  RoutingSettings routing_settings_;
  BusGraph graph_;
  unique_ptr<Router> router_;
  unordered_map<string, StopVertexIds> stops_vertex_ids_;
  vector<VertexInfo> vertices_info_;
  vector<EdgeInfo> edges_info_;
};

namespace Requests {
  struct Stop {
    string name;

    Json::Dict Process(const Database& db) const {
      const auto* stop = db.GetStop(name);
      Json::Dict dict;
      if (!stop) {
        dict["error_message"] = Json::Node("not found"s);
      } else {
        vector<Json::Node> bus_nodes;
        bus_nodes.reserve(stop->bus_names.size());
        for (const auto& bus_name : stop->bus_names) {
          bus_nodes.emplace_back(bus_name);
        }
        dict["buses"] = Json::Node(move(bus_nodes));
      }
      return dict;
    }
  };

  struct Bus {
    string name;

    Json::Dict Process(const Database& db) const {
      const auto* bus = db.GetBus(name);
      Json::Dict dict;
      if (!bus) {
        dict["error_message"] = Json::Node("not found"s);
      } else {
        dict = {
            {"stop_count", Json::Node(static_cast<int>(bus->stop_count))},
            {"unique_stop_count", Json::Node(static_cast<int>(bus->unique_stop_count))},
            {"route_length", Json::Node(bus->road_route_length)},
            {"curvature", Json::Node(bus->road_route_length / bus->geo_route_length)},
        };
      }
      return dict;
    }
  };

  struct Route {
    string stop_from;
    string stop_to;

    Json::Dict Process(const Database& db) const {
      Json::Dict dict;
      const auto route = db.FindRoute(stop_from, stop_to);
      if (!route) {
        dict["error_message"] = Json::Node("not found"s);
      } else {
        dict["total_time"] = Json::Node(route->total_time);
        vector<Json::Node> items;
        items.reserve(route->items.size());
        for (const auto& item : route->items) {
          if (holds_alternative<Database::RouteInfo::BusItem>(item)) {
            const auto& bus_item = get<Database::RouteInfo::BusItem>(item);
            Json::Dict item_dict = {
                {"type", Json::Node("Bus"s)},
                {"bus", Json::Node(bus_item.bus_name)},
                {"time", Json::Node(bus_item.time)},
                {"span_count", Json::Node(static_cast<int>(bus_item.span_count))}
            };
            items.push_back(move(item_dict));
          } else {
            const auto& wait_item = get<Database::RouteInfo::WaitItem>(item);
            Json::Dict item_dict = {
                {"type", Json::Node("Wait"s)},
                {"stop_name", Json::Node(wait_item.stop_name)},
                {"time", Json::Node(wait_item.time)},
            };
            items.push_back(move(item_dict));
          }
        }

        dict["items"] = move(items);
      }

      return dict;
    }

  };

  variant<Stop, Bus, Route> ReadQuery(const Json::Dict& attrs) {
    const string& type = attrs.at("type").AsString();
    if (type == "Bus") {
      return Bus{attrs.at("name").AsString()};
    } else if (type == "Stop") {
      return Stop{attrs.at("name").AsString()};
    } else {
      return Route{attrs.at("from").AsString(), attrs.at("to").AsString()};
    }
  }
}

vector<Json::Node> ProcessStatRequests(const Database& transport_database, const vector<Json::Node>& stat_requests) {
  vector<Json::Node> responses;
  responses.reserve(stat_requests.size());
  for (const Json::Node& request_node : stat_requests) {
    Json::Dict dict = visit([&transport_database](const auto& request) {
                              return request.Process(transport_database);
                            },
                            Requests::ReadQuery(request_node.AsMap()));
    dict["request_id"] = Json::Node(request_node.AsMap().at("id").AsInt());
    responses.push_back(Json::Node(dict));
  }
  return responses;
}

int main() {
  const auto input_doc = Json::Load(cin);
  const auto& input_map = input_doc.GetRoot().AsMap();

  const Database transport_database(
    Descriptions::ReadDescriptions(input_map.at("base_requests").AsArray()),
    input_map.at("routing_settings").AsMap()
  );

  Json::PrintValue(
    ProcessStatRequests(transport_database, input_map.at("stat_requests").AsArray()),
    cout
  );
  return 0;
}
